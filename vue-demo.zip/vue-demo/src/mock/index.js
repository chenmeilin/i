import Vue from "vue"
import Mock from "mockjs"
Vue.use(Mock)


//使用mockjs模拟数据
Mock.mock('/api/data', (req, res) => {

    this.params[a] 
    this.params[b] 
    var cs=eval(req.body)

    return {
      cs:cs,
      data: ['a','b']
    }
})
export {Mock}