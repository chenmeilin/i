<template>
	<div class="jun">
		<h1>hello word</h1>
	</div>
</template>

<style>
	
</style>

<script>
	export default {
		
	}
</script>