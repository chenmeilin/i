<template>
	<div class="slide">
		<slot name="swiper-con"></slot>

	</div>
</template>

<style lang="less" scoped>
	.slide{
		margin-top:10rem*2/75;
		width:900rem*2/75;
		display:flex;
	}
</style>

<script>
	export default{
		
	}
</script>