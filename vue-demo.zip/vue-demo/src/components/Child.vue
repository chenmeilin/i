<template>
	<div class="child">
		<span>hello word</span>
	</div>
</template>

<style>
	
</style>
<script>
	export default{

	}
</script>

