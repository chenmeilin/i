<template>
	<div class="selectionOfDetails">
		<h3>颜值保暖兼备的毛呢大衣</h3>
		<p>💕经典的毛呢大衣已然成为网红达人的出街利器，说它是冬季出镜率最高的单品之一也毫不夸张～<span>廓形遮肉、收腰显瘦，格子文艺、驼色气场十足！</span></p> 
		<p><span>款式推荐：</span>萌白甜小姐姐可以选择翻领款，想要显瘦显身材可以选择束腰款，名媛千金可以选择斗篷款，小个子妹子可以选择经典色短款……</p>		
		
		<div class="content clearfix">
			<div class="leftImg fl">
				<img src="../../../assets/image/0 (1).png">
			</div>	
			<div class="rightTxt fr">
				<h3>uiagdui</h3>
				<p>iohduiashwfnuawbfiubaufb</p>	
				<p><em>￥165.00</em></p>
				<button>查看详情</button>
			</div>	
		</div>
	</div>
</template>


<script>
	export default {
	mounted(){
			this.axios.get("/api/info_list_show").then(res=>{
				console.log(res.dataInfo[128267].list)
			})
	}
}
</script>


<style lang="less">
.selectionOfDetails{
	margin:15px 10px;
	line-height:19px;
	h3{
		font-size:16px;
		font-weight:600;
		margin-bottom:10px;
		
	}p{
		&:first-of-type{ 
			margin-bottom:15px;
			span{
			background:pink;
			padding:0 4px;
			border-radius:8px;
			}
		}
	}
}

	.content{
		margin-top:20px;
		.rightTxt{
			font-size:12px!important;
			color:#666;
			h3{
				font-size:18px!important;
				color: black;
				font-weight:600;
				border-bottom:1px solid #eee;
				margin-bottom:10px;
				padding-bottom:5px;
			}
			p{

				&:first-of-type{margin-bottom:30px;
				}
				em{
					font-size:17px!important;
					font-weight:600;
					color:black;
				}
			}
			button{
				height:30px;
				width:100px;
				background:pink;
				border:none;
				font-size:13px;
				color:#fff;
				border-radius:2px;
			}

		}
	}
</style>