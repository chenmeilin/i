<template>
	<div class="choiceness">
		<ul>
			<li @click="selectionOfDetails()" v-for="(item,index) in list">
			<img :src="item.image" alt="">
			</li>
		</ul>
	</div>
</template>

<script>
	export default {
		data(){
			return {list:[]}
		},
		mounted(){
			this.$jsonp("https://mce.mogucdn.com/jsonp/multiget/3?token=oiQuR1eDabxZ%2Bk51U8tnFJthEYeA3%2FhWO4%2B9CJdzkOnAf%2F%2BDx87GQuV1qmZhVja8e%2FN5TWl4bJd3EuWQPPJ9Bg%3D%3D&pids=122871&appPlat=m").then(res=>{
				// console.log(res.data[122871].list)
				this.list = res.data[122871].list

			})
		},
		methods:{
			selectionOfDetails(){
				this.$router.push("/selectionOfDetails")
			}
		}
	}
</script>

<style lang="less">
	.choiceness{
		ul li{
			list-style:none;
		}
		li{
			margin-top:25px;
			img{
				height: 100%;
				width:95%;
				margin:0 auto;
			}
		}
	}
</style>